# Сборка Primal Awakening через GitHub с телефона (Android)

В архиве есть workflow для обычного репозитория с исходниками. На Android проще загрузить **один ZIP-файл** в репозиторий, а затем создать небольшой workflow прямо на сайте GitHub. GitHub попробует собрать мод на сервере с Java 17 и Gradle 7.5.1. Успех не гарантирован: если компиляция упадёт, понадобится исправить журнал ошибки.

## Шаги на телефоне

1. Скачайте этот архив на телефон и создайте аккаунт/войдите на https://github.com/.
2. Создайте новый репозиторий кнопкой **New repository**. Для личного проекта можно выбрать **Private**.
3. В репозитории нажмите **Add file → Upload files** и загрузите ZIP, который скачали. Не распаковывайте его перед загрузкой. Размер архива около 20 MB.
4. Нажмите **Add file → Create new file**. В поле имени файла введите точно `.github/workflows/build.yml`.
5. Вставьте в редактор следующий текст и сохраните файл кнопкой **Commit changes**:

```yaml
name: Build Primal Awakening
on:
  push:
  workflow_dispatch:
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
          cache: gradle
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '7.5.1'
      - name: Unpack source ZIP
        run: unzip -q primal-awakening-alpha-source-v21-github-build.zip
      - name: Build mod
        working-directory: primal_awakening
        run: gradle --no-daemon build
      - uses: actions/upload-artifact@v4
        with:
          name: primal-awakening-1.9.0-alpha
          path: primal_awakening/build/libs/*.jar
          if-no-files-found: error
```

**Важно:** если ZIP-файл в репозитории имеет другое имя, измени строку `unzip -q ...` так, чтобы имя совпадало с загруженным файлом.

6. Открой вкладку **Actions**, выбери запуск **Build Primal Awakening** и дождись завершения.
7. Если рядом зелёная галочка, открой запуск и найди внизу **Artifacts**. Скачай `primal-awakening-1.9.0-alpha`, распакуй его и забери `.jar`. Если запуск красный, открой шаг `Build mod` и сохрани текст ошибки — сборка не удалась.
8. Помести полученный `.jar` в папку `mods` профиля PojavLauncher. Нужны Minecraft 1.18.2 Forge 40.2.21, Ice and Fire 2.1.13-beta-3 и Citadel 1.11.3. Перед проверкой сделай резервную копию мира.

Успешная компиляция не означает, что мод уже протестирован в Minecraft.
