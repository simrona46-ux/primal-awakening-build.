package com.primalawakening;

import com.github.alexthe666.iceandfire.entity.EntityDragonBase;
import com.github.alexthe666.iceandfire.entity.EntityDragonEgg;
import com.github.alexthe666.iceandfire.entity.util.HomePosition;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.Set;

/** Server-side nest bookkeeping and basic territorial behaviour for wild lair dragons. */
@Mod.EventBusSubscriber(modid = PrimalAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DragonNestEvents {
    private static final String PROCESSED_TAG = "primalawakening_nest_processed_v4";
    private static final float BABY_CHANCE = 0.08F;
    private static final double NEST_DEFENSE_RADIUS = 18.0D;
    private static final String DATA_NAME = "primalawakening_nests_v3";
    private static final String NEXT_DODGE_TAG = "primalawakening_next_dodge";
    private static final String NEXT_CHARGE_TAG = "primalawakening_next_charge";
    private static final String NEXT_FLANK_TAG = "primalawakening_next_flank";
    private static final long FLANK_COOLDOWN_TICKS = 100L;
    private static final long CHARGE_COOLDOWN_TICKS = 100L;
    private static final double PACK_ASSIST_RADIUS = 24.0D;
    private static final double DODGE_SCAN_RADIUS = 6.0D;
    private static final double DODGE_PATH_RADIUS = 1.65D;
    private static final double DODGE_MAX_PREDICTION_TICKS = 12.0D;
    private static final long DODGE_COOLDOWN_TICKS = 50L;
    private static final String NEXT_ROAR_TAG = "primalawakening_next_roar";
    private static final long ROAR_COOLDOWN_TICKS = 240L;
    private static final double ROAR_RADIUS = 5.5D;
    private static final String NEXT_SLAM_TAG = "primalawakening_next_slam";
    private static final String SLAM_WINDUP_TAG = "primalawakening_slam_windup_until";
    private static final String SLAM_ENRAGED_TAG = "primalawakening_slam_enraged";
    private static final String NEXT_SPECIAL_TAG = "primalawakening_next_special";
    private static final long SLAM_COOLDOWN_TICKS = 160L;
    private static final long SPECIAL_LOCKOUT_TICKS = 60L;
    private static final double SLAM_RADIUS = 3.2D;

    private DragonNestEvents() {}

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinWorldEvent event) {
        if (!(event.getWorld() instanceof ServerLevel level)) return;
        if (!(event.getEntity() instanceof EntityDragonBase dragon)) return;
        tryProcessNest(dragon, level);
    }

    /**
     * Registers a lair only when its home chunk is already loaded. If the dragon
     * joins while far from an unloaded home chunk, the periodic tick hook retries
     * later instead of silently consuming the egg/baby roll.
     */
    private static void tryProcessNest(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.isRemoved() || dragon.isMobDead() || dragon.homePos == null || dragon.isTame()) return;
        if (dragon.getPersistentData().getBoolean(PROCESSED_TAG)) return;
        if (!isInHomeDimension(dragon, level)) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !level.hasChunkAt(home)) return;

        NestData nests = NestData.get(level);
        String key = nestKey(level, home);

        // A lair may be marked in SavedData by an older build even though its egg
        // was never created, despawned, or was collected. Only treat it as complete
        // when a tagged egg entity/item is actually present nearby.
        if (hasOurEggNear(level, home)) {
            if (nests.processedNests.add(key)) nests.setDirty();
            dragon.getPersistentData().putBoolean(PROCESSED_TAG, true);
            return;
        }
        if (nests.processedNests.remove(key)) nests.setDirty();

        // HomePosition may be the structure origin rather than the visible nest floor.
        // Search for a safe exposed surface before creating the actual Ice and Fire egg.
        BlockPos eggFloor = findEggSpawnFloor(level, home);
        if (eggFloor == null) return;

        // Use Ice and Fire's real dragon-egg entity, not a collectible item. This
        // preserves the mod's egg rendering and its native temperature/hatching logic.
        EntityDragonEgg eggEntity = dragon.createEgg(dragon);
        if (eggEntity == null) return;
        eggEntity.moveTo(eggFloor.getX() + 0.5D, eggFloor.getY() + 1.02D,
                eggFloor.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        eggEntity.setOwnerId(dragon.getUUID());
        eggEntity.setGlowingTag(true);
        eggEntity.getPersistentData().putBoolean("primalawakening_nest_egg", true);
        // Do not persist the lair as processed if the server refuses the egg entity.
        if (!level.addFreshEntity(eggEntity)) return;

        // Persist only after the egg was actually accepted by the level.
        nests.processedNests.add(key);
        nests.setDirty();
        dragon.getPersistentData().putBoolean(PROCESSED_TAG, true);

        // The 8% roll is per nest, not per dragon. At most one baby is attempted.
        if (level.random.nextFloat() < BABY_CHANCE) {
            Entity created = dragon.getType().create(level);
            if (created instanceof EntityDragonBase baby) {
                baby.moveTo(home.getX() + 1.5D, home.getY(), home.getZ() + 1.5D,
                        level.random.nextFloat() * 360.0F, 0.0F);
                baby.setVariant(dragon.getVariant());
                baby.setGender(level.random.nextBoolean());
                baby.growDragon(1);
                baby.homePos = new HomePosition(home, level);
                baby.hasHomePosition = true;
                baby.getPersistentData().putBoolean(PROCESSED_TAG, true);
                if (level.noCollision(baby)) {
                    level.addFreshEntity(baby);
                } else {
                    baby.discard();
                }
            } else if (created != null) {
                created.discard();
            }
        }
    }


    private static boolean hasOurEggNear(ServerLevel level, BlockPos home) {
        AABB search = new AABB(home).inflate(16.0D, 10.0D, 16.0D);
        boolean hasEntityEgg = !level.getEntitiesOfClass(EntityDragonEgg.class, search,
                egg -> egg.getPersistentData().getBoolean("primalawakening_nest_egg")).isEmpty();
        if (hasEntityEgg) return true;
        // Also recognize tagged item-eggs from earlier alpha versions during migration.
        return !level.getEntitiesOfClass(ItemEntity.class, search,
                item -> item.getPersistentData().getBoolean("primalawakening_nest_egg")).isEmpty();
    }

    /**
     * Finds a safe egg placement near a lair's home position. Search up to a 17x17
     * horizontal area and eight blocks above/below the saved home Y level because
     * structure home positions are not always located on the visible nest floor.
     */
    private static BlockPos findEggSpawnFloor(ServerLevel level, BlockPos home) {
        int[] yOffsets = {0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8, -8};
        for (int radius = 0; radius <= 8; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    for (int dy : yOffsets) {
                        BlockPos floor = home.offset(dx, dy, dz);
                        if (!level.hasChunkAt(floor) || !level.hasChunkAt(floor.above(2))) continue;
                        if (!isSafeEggFloor(level, floor)) continue;
                        if (!level.getBlockState(floor.above()).isAir()
                                || !level.getBlockState(floor.above(2)).isAir()) continue;
                        if (!level.getFluidState(floor.above()).isEmpty()
                                || !level.getFluidState(floor.above(2)).isEmpty()) continue;
                        return floor.immutable();
                    }
                }
            }
        }
        return null;
    }

    /** Reject unstable or hazardous surfaces so the egg is not placed on fire, fluids, or damaging blocks. */
    private static boolean isSafeEggFloor(ServerLevel level, BlockPos floor) {
        var state = level.getBlockState(floor);
        if (!state.isFaceSturdy(level, floor, Direction.UP)) return false;
        if (!level.getFluidState(floor).isEmpty()) return false;
        return !state.is(Blocks.MAGMA_BLOCK)
                && !state.is(Blocks.CACTUS)
                && !state.is(Blocks.CAMPFIRE)
                && !state.is(Blocks.SOUL_CAMPFIRE)
                && !state.is(Blocks.FIRE)
                && !state.is(Blocks.SOUL_FIRE)
                && !state.is(Blocks.SWEET_BERRY_BUSH)
                && !state.is(Blocks.WITHER_ROSE)
                && !state.is(Blocks.POWDER_SNOW);
    }

    /**
     * A wild adult with a home becomes territorial when a player approaches the lair.
     * The existing Ice and Fire combat AI still chooses and executes the actual attacks.
     */
    @SubscribeEvent
    public static void onDragonTick(LivingEvent.LivingUpdateEvent event) {
        if (!(event.getEntityLiving() instanceof EntityDragonBase dragon)) return;
        if (!(dragon.level instanceof ServerLevel level)) return;
        if (dragon.isRemoved() || dragon.isTame() || dragon.isMobDead()) return;

        // Retry nest processing if the dragon loaded before its home chunk did.
        if (dragon.tickCount % 100 == 0 && dragon.homePos != null
                && !dragon.getPersistentData().getBoolean(PROCESSED_TAG)) {
            tryProcessNest(dragon, level);
        }

        // Combat layer: wild adult dragons can make a short evasive sidestep against
        // player-fired projectiles. The cooldown is stored in persistent entity data.
        if (dragon.getDragonStage() >= 3 && dragon.tickCount % 5 == 0) {
            tryDodgeProjectile(dragon, level);
            tryCloseDistance(dragon, level);
            tryRoarShockwave(dragon, level);
            tryGroundSlam(dragon, level);
        }

        // Dragons from the same lair coordinate on an already identified player target.
        // This runs server-side every second and leaves Ice and Fire attack execution intact.
        if (dragon.tickCount % 20 == 0) {
            rallyPack(dragon, level);
            tryPackFlank(dragon, level);
        }

        // Territorial logic runs less often to keep the extra AI inexpensive.
        if (dragon.tickCount % 20 != 0 || dragon.homePos == null || dragon.getTarget() != null) return;
        if (dragon.getDragonStage() < 2) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        if (dragon.distanceToSqr(home.getX() + 0.5D, home.getY() + 0.5D, home.getZ() + 0.5D)
                > NEST_DEFENSE_RADIUS * NEST_DEFENSE_RADIUS) return;

        Player intruder = level.getNearestPlayer(dragon, 12.0D);
        if (intruder == null || intruder.isSpectator() || intruder.isCreative()) return;
        if (intruder.distanceToSqr(home.getX() + 0.5D, home.getY() + 0.5D, home.getZ() + 0.5D)
                <= NEST_DEFENSE_RADIUS * NEST_DEFENSE_RADIUS) {
            dragon.setTarget(intruder);
        }
    }

    /** Nearby wild dragons sharing the same home retaliate when a player injures one of them. */
    @SubscribeEvent
    public static void onDragonHurt(LivingHurtEvent event) {
        if (!(event.getEntityLiving() instanceof EntityDragonBase hurtDragon)) return;
        if (!(hurtDragon.level instanceof ServerLevel level)) return;
        if (!(event.getSource().getEntity() instanceof Player attacker)) return;
        if (attacker.isCreative() || attacker.isSpectator() || hurtDragon.isTame()) return;
        if (hurtDragon.homePos == null) return;

        BlockPos home = hurtDragon.homePos.getPosition();
        if (home == null) return;
        for (Entity entity : level.getEntities(hurtDragon,
                hurtDragon.getBoundingBox().inflate(20.0D),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally == hurtDragon || ally.isTame() || ally.isRemoved() || ally.homePos == null) continue;
            if (!home.equals(ally.homePos.getPosition())) continue;
            if (ally.getTarget() == null) ally.setTarget(attacker);
        }
        if (hurtDragon.getTarget() == null) hurtDragon.setTarget(attacker);
    }



    /**
     * Shares a player target with nearby wild dragons from the same home position.
     * Tamed dragons, unrelated lairs, and non-player targets are deliberately excluded.
     */
    private static void rallyPack(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.isTame() || dragon.getDragonStage() < 2 || dragon.homePos == null) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        if (dragon.distanceToSqr(target) > PACK_ASSIST_RADIUS * PACK_ASSIST_RADIUS) return;

        for (Entity entity : level.getEntities(dragon, dragon.getBoundingBox().inflate(PACK_ASSIST_RADIUS),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally.isRemoved() || ally.isTame() || ally.isMobDead() || ally.getDragonStage() < 2) continue;
            if (ally.homePos == null || !home.equals(ally.homePos.getPosition())) continue;
            if (!isInHomeDimension(ally, level)) continue;
            if (ally.getTarget() == null && ally.distanceToSqr(target) <= PACK_ASSIST_RADIUS * PACK_ASSIST_RADIUS) {
                ally.setTarget(target);
            }
        }
    }

    /**
     * Gives an engaged adult a small lateral reposition when a pack ally is also
     * fighting the same player. This is deliberately an impulse, not a teleport: it
     * respects block collision and has a cooldown so vanilla pathfinding can recover.
     */
    private static void tryPackFlank(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || dragon.isTame() || !dragon.isOnGround()
                || dragon.isFlying() || dragon.isBreathingFire() || dragon.homePos == null) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        double distanceSqr = dragon.distanceToSqr(target);
        if (distanceSqr < 36.0D || distanceSqr > 225.0D) return; // 6–15 blocks
        long now = level.getGameTime();
        if (now < dragon.getPersistentData().getLong(NEXT_FLANK_TAG)) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        boolean engagedAlly = false;
        for (Entity entity : level.getEntities(dragon, dragon.getBoundingBox().inflate(PACK_ASSIST_RADIUS),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally.isRemoved() || ally.isTame() || ally.isMobDead() || ally.getDragonStage() < 2) continue;
            if (ally.homePos == null || !home.equals(ally.homePos.getPosition())) continue;
            if (!isInHomeDimension(ally, level) || ally.getTarget() != target) continue;
            if (ally.distanceToSqr(target) <= PACK_ASSIST_RADIUS * PACK_ASSIST_RADIUS) {
                engagedAlly = true;
                break;
            }
        }
        if (!engagedAlly) return;

        Vec3 awayFromTarget = new Vec3(dragon.getX() - target.getX(), 0.0D,
                dragon.getZ() - target.getZ());
        if (awayFromTarget.lengthSqr() < 1.0E-4D) return;
        awayFromTarget = awayFromTarget.normalize();
        Vec3 side = new Vec3(-awayFromTarget.z, 0.0D, awayFromTarget.x);
        if ((dragon.getId() & 1) != 0) side = side.scale(-1.0D);
        Vec3 opposite = side.scale(-1.0D);
        boolean canSide = level.noCollision(dragon, dragon.getBoundingBox().move(side.x * 1.2D, 0.0D, side.z * 1.2D));
        boolean canOpposite = level.noCollision(dragon, dragon.getBoundingBox().move(opposite.x * 1.2D, 0.0D, opposite.z * 1.2D));
        if (!canSide && !canOpposite) return;
        if (!canSide) side = opposite;

        dragon.setDeltaMovement(dragon.getDeltaMovement().add(side.x * 0.16D, 0.025D, side.z * 0.16D));
        dragon.hasImpulse = true;
        dragon.getPersistentData().putLong(NEXT_FLANK_TAG, now + FLANK_COOLDOWN_TICKS);
        level.sendParticles(ParticleTypes.CLOUD, dragon.getX(), dragon.getY() + 0.15D, dragon.getZ(),
                4, 0.25D, 0.05D, 0.25D, 0.005D);
    }

    /**
     * Prevents dragons from the same lair from stacking their roar, slam, and charge
     * at the same moment. An ally's shared special lockout acts as a short coordination
     * signal; this does not reserve the attack permanently or affect unrelated lairs.
     */
    private static boolean hasNearbyPackSpecialInProgress(EntityDragonBase dragon, ServerLevel level, long now) {
        if (dragon.homePos == null || !isInHomeDimension(dragon, level)) return false;
        BlockPos home = dragon.homePos.getPosition();
        if (home == null) return false;

        for (Entity entity : level.getEntities(dragon,
                dragon.getBoundingBox().inflate(PACK_ASSIST_RADIUS),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally == dragon || ally.isRemoved() || ally.isTame() || ally.isMobDead()) continue;
            if (ally.getDragonStage() < 2 || ally.homePos == null) continue;
            if (!home.equals(ally.homePos.getPosition()) || !isInHomeDimension(ally, level)) continue;
            if (ally.getPersistentData().getLong(NEXT_SPECIAL_TAG) > now) return true;
        }
        return false;
    }

    /**
     * A short grounded pursuit burst helps adult wild dragons close a gap when a
     * player kites them on foot. It does not replace normal pathfinding, and it is
     * skipped while flying, breathing fire, or when the forward bounding box collides.
     */
    private static void tryCloseDistance(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || !dragon.isOnGround()
                || dragon.isBreathingFire() || dragon.isFlying()) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        double distanceSqr = dragon.distanceToSqr(target);
        if (distanceSqr < 64.0D || distanceSqr > 324.0D) return; // 8–18 blocks

        long now = level.getGameTime();
        boolean enraged = dragon.getMaxHealth() > 0.0F
                && dragon.getHealth() / dragon.getMaxHealth() <= 0.30F;
        long cooldown = enraged ? 70L : CHARGE_COOLDOWN_TICKS;
        if (now < dragon.getPersistentData().getLong(NEXT_CHARGE_TAG)) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SPECIAL_TAG)) return;
        if (hasNearbyPackSpecialInProgress(dragon, level, now)) return;

        // Aim slightly ahead of a sprinting target, but cap the prediction so the
        // burst cannot turn into an abrupt, excessively large movement impulse.
        Vec3 targetMotion = target.getDeltaMovement();
        double lead = target.isSprinting() ? 2.0D : 0.6D;
        Vec3 predicted = target.position().add(targetMotion.x * lead, 0.0D, targetMotion.z * lead);
        Vec3 toward = new Vec3(predicted.x - dragon.getX(), 0.0D, predicted.z - dragon.getZ());
        if (toward.lengthSqr() < 1.0E-4D) return;
        Vec3 impulse = toward.normalize().scale(enraged ? 0.34D : 0.27D);
        if (!level.noCollision(dragon, dragon.getBoundingBox().move(impulse.x * 2.0D, 0.0D, impulse.z * 2.0D))) {
            // Do not spend the cooldown when a wall or another collision blocks the burst.
            return;
        }

        dragon.setDeltaMovement(dragon.getDeltaMovement().add(impulse.x, enraged ? 0.12D : 0.08D, impulse.z));
        dragon.hasImpulse = true;
        dragon.getPersistentData().putLong(NEXT_CHARGE_TAG, now + cooldown);
        dragon.getPersistentData().putLong(NEXT_SPECIAL_TAG, now + 25L);
        level.sendParticles(enraged ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
                dragon.getX(), dragon.getY() + 0.2D, dragon.getZ(),
                enraged ? 10 : 6, 0.35D, 0.08D, 0.35D, 0.015D);
    }

    /**
     * Short-range roar shockwave: adult wild dragons can disrupt nearby players,
     * creating space when a fight gets too close. It uses vanilla effects and has
     * a persistent world-time cooldown, so reloading the dragon cannot reset it.
     */
    private static void tryRoarShockwave(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || dragon.isBreathingFire() || dragon.isFlying()) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        // A badly wounded adult enters an enraged phase. This strengthens the existing
        // roar without adding another ticking task or replacing Ice and Fire's AI.
        boolean enraged = dragon.getMaxHealth() > 0.0F
                && dragon.getHealth() / dragon.getMaxHealth() <= 0.30F;
        double radius = enraged ? 7.0D : ROAR_RADIUS;
        if (dragon.distanceToSqr(target) > radius * radius) return;

        long now = level.getGameTime();
        long roarCooldown = enraged ? 180L : ROAR_COOLDOWN_TICKS;
        if (now < dragon.getPersistentData().getLong(NEXT_ROAR_TAG)) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SPECIAL_TAG)) return;
        if (hasNearbyPackSpecialInProgress(dragon, level, now)) return;

        level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                SoundSource.HOSTILE, enraged ? 1.35F : 1.15F, enraged ? 0.58F : 0.72F);
        level.sendParticles(ParticleTypes.CLOUD, dragon.getX(), dragon.getY() + 0.2D, dragon.getZ(),
                enraged ? 32 : 18, enraged ? 1.25D : 0.8D, 0.12D,
                enraged ? 1.25D : 0.8D, 0.025D);

        for (Player player : level.getEntitiesOfClass(Player.class,
                dragon.getBoundingBox().inflate(radius))) {
            if (player.isRemoved() || player.isDeadOrDying() || player.isCreative() || player.isSpectator()) continue;
            if (player.distanceToSqr(dragon) > radius * radius) continue;

            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                    enraged ? 60 : 35, enraged ? 2 : 1));
            if (enraged) {
                player.hurt(DamageSource.mobAttack(dragon), 2.0F);
            }
            double dx = player.getX() - dragon.getX();
            double dz = player.getZ() - dragon.getZ();
            if (dx * dx + dz * dz < 1.0E-4D) {
                dx = (player.getId() & 1) == 0 ? 1.0D : -1.0D;
                dz = 0.0D;
            }
            player.knockback(enraged ? 1.0D : 0.72D, dx, dz);
        }
        dragon.getPersistentData().putLong(NEXT_ROAR_TAG, now + roarCooldown);
        dragon.getPersistentData().putLong(NEXT_SPECIAL_TAG, now + SPECIAL_LOCKOUT_TICKS);
    }

    /**
     * Close-range ground slam for adult wild dragons. It damages and pushes nearby players;
     * a shared short lockout prevents the slam and roar from firing together.
     */
    private static void tryGroundSlam(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || !dragon.isOnGround() || dragon.isBreathingFire() || dragon.isFlying()) return;

        long now = level.getGameTime();
        long windupUntil = dragon.getPersistentData().getLong(SLAM_WINDUP_TAG);
        Player target = dragon.getTarget() instanceof Player player ? player : null;

        // The enraged state is snapshotted when the warning starts so the attack's
        // radius and damage cannot change unexpectedly during its wind-up.
        if (windupUntil > 0L) {
            boolean enragedSlam = dragon.getPersistentData().getBoolean(SLAM_ENRAGED_TAG);
            double slamRadius = enragedSlam ? 4.2D : SLAM_RADIUS;
            if (target == null || target.isRemoved() || target.isDeadOrDying()
                    || target.isCreative() || target.isSpectator()
                    || dragon.distanceToSqr(target) > slamRadius * slamRadius
                    || !dragon.isOnGround() || dragon.isFlying() || dragon.isBreathingFire()) {
                dragon.getPersistentData().putLong(SLAM_WINDUP_TAG, 0L);
                dragon.getPersistentData().putBoolean(SLAM_ENRAGED_TAG, false);
                return;
            }
            if (now < windupUntil) {
                // Keep a visible ground-level ring during the wind-up so players can
                // read the danger zone instead of relying on sound alone.
                double ringY = dragon.getY() + 0.12D;
                int points = enragedSlam ? 16 : 12;
                for (int i = 0; i < points; i++) {
                    double angle = (Math.PI * 2.0D * i) / points;
                    double px = dragon.getX() + Math.cos(angle) * slamRadius;
                    double pz = dragon.getZ() + Math.sin(angle) * slamRadius;
                    level.sendParticles(enragedSlam ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
                            px, ringY, pz, 1, 0.02D, 0.01D, 0.02D, 0.0D);
                }
                return;
            }

            level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                    SoundSource.HOSTILE, enragedSlam ? 1.2F : 0.9F, enragedSlam ? 0.78F : 1.15F);
            for (Player player : level.getEntitiesOfClass(Player.class,
                    dragon.getBoundingBox().inflate(slamRadius))) {
                if (player.isRemoved() || player.isDeadOrDying() || player.isCreative() || player.isSpectator()) continue;
                if (player.distanceToSqr(dragon) > slamRadius * slamRadius) continue;
                player.hurt(DamageSource.mobAttack(dragon), enragedSlam ? 6.0F : 4.0F);
                double dx = player.getX() - dragon.getX();
                double dz = player.getZ() - dragon.getZ();
                if (dx * dx + dz * dz < 1.0E-4D) {
                    dx = (player.getId() & 1) == 0 ? 1.0D : -1.0D;
                    dz = 0.0D;
                }
                player.knockback(enragedSlam ? 1.25D : 0.95D, dx, dz);
            }
            dragon.getPersistentData().putLong(SLAM_WINDUP_TAG, 0L);
            dragon.getPersistentData().putBoolean(SLAM_ENRAGED_TAG, false);
            dragon.getPersistentData().putLong(NEXT_SLAM_TAG, now + (enragedSlam ? 120L : SLAM_COOLDOWN_TICKS));
            return;
        }

        if (target == null || target.isRemoved() || target.isDeadOrDying()
                || target.isCreative() || target.isSpectator()) return;
        boolean enragedSlam = dragon.getMaxHealth() > 0.0F
                && dragon.getHealth() / dragon.getMaxHealth() <= 0.30F;
        double slamRadius = enragedSlam ? 4.2D : SLAM_RADIUS;
        if (dragon.distanceToSqr(target) > slamRadius * slamRadius) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SLAM_TAG)) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SPECIAL_TAG)) return;
        if (hasNearbyPackSpecialInProgress(dragon, level, now)) return;

        // Telegraph the attack: enraged dragons give a slightly longer warning,
        // but their larger damage zone remains clearly marked with flame particles.
        dragon.getPersistentData().putLong(SLAM_WINDUP_TAG, now + (enragedSlam ? 14L : 10L));
        dragon.getPersistentData().putBoolean(SLAM_ENRAGED_TAG, enragedSlam);
        dragon.getPersistentData().putLong(NEXT_SPECIAL_TAG, now + SPECIAL_LOCKOUT_TICKS);
        level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                SoundSource.HOSTILE, enragedSlam ? 1.0F : 0.75F, enragedSlam ? 0.82F : 1.35F);
        level.sendParticles(enragedSlam ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
                dragon.getX(), dragon.getY() + 0.15D, dragon.getZ(),
                enragedSlam ? 28 : 18, enragedSlam ? 1.2D : 0.9D,
                0.08D, enragedSlam ? 1.2D : 0.9D, 0.02D);
    }

    /**
     * Performs a cooldown-limited lateral dodge when a player projectile is visibly
     * travelling toward an adult wild dragon. Vanilla/Ice and Fire attack AI is untouched.
     */
    private static void tryDodgeProjectile(EntityDragonBase dragon, ServerLevel level) {
        long now = level.getGameTime();
        if (now < dragon.getPersistentData().getLong(NEXT_DODGE_TAG)) return;

        for (Projectile projectile : level.getEntitiesOfClass(Projectile.class,
                dragon.getBoundingBox().inflate(DODGE_SCAN_RADIUS),
                candidate -> !candidate.isRemoved() && candidate.getOwner() instanceof Player)) {
            Vec3 projectileVelocity = projectile.getDeltaMovement();
            if (projectileVelocity.lengthSqr() < 1.0E-4D) continue;

            // Predict the projectile's closest point on its current trajectory. This
            // avoids wasting a dodge on arrows that are moving toward the dragon's
            // general direction but will actually pass well to the side.
            Vec3 dragonCenter = dragon.position().add(0.0D, dragon.getBbHeight() * 0.5D, 0.0D);
            Vec3 towardDragon = dragonCenter.subtract(projectile.position());
            double timeToClosest = towardDragon.dot(projectileVelocity) / projectileVelocity.lengthSqr();
            if (timeToClosest <= 0.0D || timeToClosest > DODGE_MAX_PREDICTION_TICKS) continue;
            Vec3 closestPoint = projectile.position().add(projectileVelocity.scale(timeToClosest));
            if (closestPoint.distanceToSqr(dragonCenter) > DODGE_PATH_RADIUS * DODGE_PATH_RADIUS) continue;

            // Check both sidesteps before committing. A fixed left/right choice can
            // push a dragon into a cliff or wall, so prefer the clear side when only
            // one candidate bounding box is collision-free.
            Vec3 lateral = new Vec3(-projectileVelocity.z, 0.0D, projectileVelocity.x);
            if (lateral.lengthSqr() < 1.0E-4D) lateral = new Vec3(1.0D, 0.0D, 0.0D);
            lateral = lateral.normalize().scale(0.48D);
            Vec3 opposite = lateral.scale(-1.0D);
            boolean canMoveLateral = level.noCollision(dragon,
                    dragon.getBoundingBox().move(lateral.x, 0.0D, lateral.z));
            boolean canMoveOpposite = level.noCollision(dragon,
                    dragon.getBoundingBox().move(opposite.x, 0.0D, opposite.z));
            if (!canMoveLateral && !canMoveOpposite) continue;

            Vec3 dodge;
            if (canMoveLateral && canMoveOpposite) {
                dodge = (dragon.getId() & 1) == 0 ? lateral : opposite;
            } else {
                dodge = canMoveLateral ? lateral : opposite;
            }
            dragon.setDeltaMovement(dragon.getDeltaMovement().add(dodge.x, 0.16D, dodge.z));
            dragon.hasImpulse = true;
            dragon.getPersistentData().putLong(NEXT_DODGE_TAG, now + DODGE_COOLDOWN_TICKS);
            return;
        }
    }

    private static boolean isInHomeDimension(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.homePos == null) return false;
        String homeDimension = dragon.homePos.getDimension();
        // Empty dimensions can occur in legacy HomePosition data; treat those as local.
        return homeDimension == null || homeDimension.isEmpty()
                || homeDimension.equals(level.dimension().location().toString());
    }

    private static String nestKey(ServerLevel level, BlockPos home) {
        return level.dimension().location() + "|" + home.getX() + "," + home.getY() + "," + home.getZ();
    }

    /** Minimal persistent per-dimension registry; survives save/reload and avoids per-dragon duplication. */
    public static final class NestData extends SavedData {
        private final Set<String> processedNests = new HashSet<>();

        public NestData() {}

        public static NestData get(ServerLevel level) {
            return level.getDataStorage().computeIfAbsent(NestData::load, NestData::new, DATA_NAME);
        }

        public static NestData load(CompoundTag tag) {
            NestData data = new NestData();
            ListTag list = tag.getList("processed", 8);
            for (int i = 0; i < list.size(); i++) data.processedNests.add(list.getString(i));
            return data;
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            ListTag list = new ListTag();
            for (String key : processedNests) list.add(StringTag.valueOf(key));
            tag.put("processed", list);
            return tag;
        }
    }
}
