package com.primalawakening;

import net.minecraftforge.fml.common.Mod;

@Mod(PrimalAwakening.MOD_ID)
public final class PrimalAwakening {
    public static final String MOD_ID = "primalawakening";

    public PrimalAwakening() {
        // Initial alpha uses Forge events and does not replace Ice and Fire's files.
    }
}
